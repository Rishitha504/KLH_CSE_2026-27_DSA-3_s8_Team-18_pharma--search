// Hand-built algorithms from the syllabus (no library search helpers).

// Module 2: Knuth-Morris-Pratt, O(n+m). Returns whether p occurs in t and the comparisons used.
function kmp(t,p){
  const f=[0];
  for(let i=1,k=0;i<p.length;i++){while(k&&p[i]!=p[k])k=f[k-1];if(p[i]==p[k])k++;f[i]=k}
  let k=0,steps=0;
  for(let i=0;i<t.length;i++){steps++;while(k&&t[i]!=p[k])k=f[k-1];if(t[i]==p[k])k++;if(k==p.length)return{ok:true,steps}}
  return{ok:false,steps};
}

// Module 2: Rabin-Karp with a polynomial rolling hash, average O(n+m).
function rabinKarp(t,p){
  const B=256,M=1000000007,m=p.length;
  if(!m||m>t.length)return false;
  let h=0,w=0,pw=1;
  for(let i=0;i<m;i++){h=(h*B+p.charCodeAt(i))%M;w=(w*B+t.charCodeAt(i))%M;if(i)pw=pw*B%M}
  for(let i=0;;i++){
    if(h==w&&t.substr(i,m)==p)return true;
    if(i+m>=t.length)return false;
    w=((w-t.charCodeAt(i)*pw%M+M)*B+t.charCodeAt(i+m))%M;
  }
}

// Module 3: Wagner-Fischer edit distance (Levenshtein), O(nm) with one row of memory.
function editDistance(a,b){
  let prev=[...Array(b.length+1).keys()];
  for(let i=1;i<=a.length;i++){
    const cur=[i];
    for(let j=1;j<=b.length;j++)cur[j]=Math.min(prev[j]+1,cur[j-1]+1,prev[j-1]+(a[i-1]==b[j-1]?0:1));
    prev=cur;
  }
  return prev[b.length];
}

// Module 2: suffix array (O(n log^2 n) style sort) plus binary search for prefix lookup.
function buildSuffixArray(s){
  return [...Array(s.length).keys()].sort((a,b)=>s.slice(a)<s.slice(b)?-1:1);
}
function suffixLowerBound(text,sa,p){
  let lo=0,hi=sa.length;
  while(lo<hi){const mid=(lo+hi)>>1;text.slice(sa[mid],sa[mid]+p.length)<p?lo=mid+1:hi=mid}
  return lo;
}

// Module 6: Miller-Rabin primality test (Monte Carlo; these bases are exact for numbers below 3 trillion).
function powMod(b,e,m){let r=1n;b%=m;while(e>0n){if(e&1n)r=r*b%m;b=b*b%m;e>>=1n}return r}
function isPrime(n){
  n=BigInt(n);
  if(n<2n)return false;
  for(const p of[2n,3n,5n,7n,11n,13n])if(n%p==0n)return n==p;
  let d=n-1n,r=0;
  while(d%2n==0n){d/=2n;r++}
  for(const a of[2n,3n,5n,7n,11n]){
    let x=powMod(a,d,n);
    if(x==1n||x==n-1n)continue;
    let witness=true;
    for(let i=1;i<r;i++){x=x*x%n;if(x==n-1n){witness=false;break}}
    if(witness)return false;
  }
  return true;
}
// Las Vegas style: keep drawing random numbers until Miller-Rabin accepts one.
function randomPrimeReceipt(){let n;do{n=Math.floor(Math.random()*900000)+100000}while(!isPrime(n));return n}

// Module 6: reservoir sampling, uniform k-sample from a stream in one pass.
function reservoir(a,k){
  const r=a.slice(0,k);
  for(let i=k;i<a.length;i++){const j=Math.floor(Math.random()*(i+1));if(j<k)r[j]=a[i]}
  return r;
}

// Module 6: double polynomial hash for passwords (demo only, not production security).
function hashPassword(s){
  let a=7,b=11;
  for(const c of s){a=(a*131+c.charCodeAt(0))%1000000007;b=(b*137+c.charCodeAt(0))%998244353}
  return a.toString(36)+b.toString(36);
}
