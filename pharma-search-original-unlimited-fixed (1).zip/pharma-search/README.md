# Pharma Search

File-based pharmacy website (HTML, CSS, JavaScript). No database, no install.

## Run in VS Code
1. Open this folder in VS Code.
2. Install the "Live Server" extension, right-click index.html, choose "Open with Live Server".
   (Double-clicking index.html also works.)

## Logins
- Admin: username `admin`, password `admin123`
- Customer: click Customer login, then Register, then log in.

## Files
- data.js: starting medicines and substitutes
- algorithms.js: KMP, Rabin-Karp, edit distance, suffix array, Miller-Rabin, reservoir sampling, password hash
- app.js: customer and admin screens
- style.css: design

Data (medicines, users, transactions) is saved in the browser's local storage. To reset, clear site data.
