const $=s=>document.querySelector(s),app=$('#app');
const load=(k,d)=>{try{return JSON.parse(localStorage.getItem('ps_'+k))||d}catch{return d}};
const store=(k,v)=>localStorage.setItem('ps_'+k,JSON.stringify(v));
let meds=load('meds',SEED),users=load('users',[]),txns=load('txns',[]),me=null,tab='search',res=null,filters={q:'',cat:'all',sort:'relevance'};
const save=()=>{store('meds',meds);store('users',users);store('txns',txns)};
const days=m=>Math.round((new Date(m.exp)-new Date())/864e5);
const status=m=>days(m)<0?['Expired','bad']:m.stock==0?['Out of stock','bad']:m.stock<=10?['Low stock','warn']:days(m)<=60?['Expiring soon','warn']:['In stock','ok'];
const rs=n=>'₹'+n;
const esc=s=>String(s).replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');
const cats=()=>[...new Set(meds.map(m=>m.cat))].sort();
function filtered(list=meds){let a=list.filter(m=>filters.cat==='all'||m.cat===filters.cat);if(filters.sort==='priceAsc')a.sort((x,y)=>x.price-y.price);if(filters.sort==='priceDesc')a.sort((x,y)=>y.price-x.price);if(filters.sort==='stock')a.sort((x,y)=>y.stock-x.stock);if(filters.sort==='expiry')a.sort((x,y)=>new Date(x.exp)-new Date(y.exp));return a;}
const toast=t=>{const e=$('#toast');e.textContent=t;e.className='show';setTimeout(()=>e.className='',2400)};

// Suffix-array index over all medicine names (autocomplete)
let TXT='',OWN=[],SA=[];
function buildIndex(){
  TXT='';OWN=[];
  meds.forEach((m,i)=>{const s=m.name.toLowerCase()+'|';for(let k=0;k<s.length;k++)OWN.push(i);TXT+=s});
  SA=buildSuffixArray(TXT);
}
function suggest(p){
  p=p.trim().toLowerCase();if(!p)return[];
  let lo=suffixLowerBound(TXT,SA,p);const out=new Set();
  for(;lo<SA.length&&TXT.substr(SA[lo],p.length)==p&&out.size<5;lo++)out.add(meds[OWN[SA[lo]]].name);
  return[...out];
}

// Search: KMP on names, Rabin-Karp on manufacturer and category, edit distance when nothing matches
function search(q){
  q=q.trim().toLowerCase();if(!q)return null;
  const r=[];let steps=0;
  meds.forEach(m=>{
    const k=kmp(m.name.toLowerCase(),q);steps+=k.steps;
    if(k.ok)r.push({m,why:'KMP'});
    else if(rabinKarp(m.mfr.toLowerCase(),q)||rabinKarp(m.cat.toLowerCase(),q))r.push({m,why:'Rabin-Karp'});
  });
  if(r.length)return{r,steps};
  const fuzzy=meds.map(m=>{const n=m.name.toLowerCase();return{m,d:Math.min(editDistance(q,n),editDistance(q,n.split(' ')[0]))}})
    .sort((a,b)=>a.d-b.d).filter(x=>x.d<=Math.max(2,q.length>>2)).slice(0,3);
  return{r:[],fuzzy,steps};
}

// ---------- Home and login ----------
function home(){
  me=null;
  app.innerHTML=`<header class="hero"><i class="cap c1"></i><i class="cap c2"></i><i class="cap c3"></i>
  <nav class="brand"><b>Pharma<span>Search</span></b></nav>
  <div class="hero-in"><div><h1>Find the medicine, even when you mistype it.</h1>
  <p>Search by name, maker or category, compare prices, and see what to take instead when a medicine is out of stock.</p></div>
  <div class="roles">
  <button class="role" onclick="auth('customer')"><h3>Customer login</h3><p>Search medicines, buy, and view your transactions.</p></button>
  <button class="role admin" onclick="auth('admin')"><h3>Admin login</h3><p>Manage stock, expiry dates and every transaction.</p></button>
  </div></div></header>
  <section class="algos"><h2>The algorithms behind every search</h2>
  <div class="grid">${ALGOS.map(a=>`<div class="al"><b>${a[0]}</b><span>${a[1]}</span></div>`).join('')}</div></section>
  <footer>Built by P. Asritha Chowdary, Y. Akshaya and K. Rishitha Chowdary</footer>`;
}
function auth(role,mode='login'){
  const adm=role=='admin',reg=mode=='register';
  app.innerHTML=`<div class="authwrap"><form class="authcard" onsubmit="return go(event,'${role}','${mode}')">
  <h2>${adm?'Admin login':reg?'Create your account':'Customer login'}</h2>
  ${reg?'<label>Full name<input name="name" required></label>':''}
  <label>Username<input name="u" required autocomplete="username"></label>
  <label>Password<input name="p" type="password" required minlength="4" autocomplete="current-password"></label>
  <button class="btn">${adm?'Log in as admin':reg?'Register':'Log in'}</button>
  ${adm?'':`<p class="sw">${reg?'Already have an account?':'New here?'} <a href="#" onclick="auth('customer','${reg?'login':'register'}');return false">${reg?'Log in':'Register'}</a></p>`}
  <button type="button" class="back" onclick="home()">Back to home</button></form></div>`;
}
function go(e,role,mode){
  e.preventDefault();
  const f=new FormData(e.target),u=f.get('u').trim().toLowerCase(),h=hashPassword(f.get('p'));
  if(role=='admin'){
    if(u=='admin'&&h==hashPassword('admin123')){me={role,name:'Admin'};tab='stock';dash()}
    else toast('Wrong admin username or password');
    return false;
  }
  if(mode=='register'){
    if(users.some(x=>x.u==u)){toast('Username taken. Pick another or log in.');return false}
    users.push({u,name:f.get('name').trim(),h});save();toast('Account created. Log in now.');auth('customer');return false;
  }
  const x=users.find(x=>x.u==u&&x.h==h);
  if(!x){toast('No match. Check your details or register first.');return false}
  me={role,u,name:x.name};tab='search';res=null;dash();return false;
}

// ---------- Dashboard shell ----------
function dash(){
  const adm=me.role=='admin',tabs=adm?[['stock','Inventory'],['add','Add medicine'],['txn','Transactions']]:[['search','Search'],['txn','My transactions']];
  app.innerHTML=`<div class="top"><b class="logo">Pharma<span>Search</span></b>
  <nav>${tabs.map(t=>`<button class="${tab==t[0]?'on':''}" onclick="tab='${t[0]}';dash()">${t[1]}</button>`).join('')}</nav>
  <div class="who"><span>${esc(me.name)}</span><button class="out" onclick="home()">Log out</button></div></div>
  <main>${adm?admin():cust()}</main>`;
  if(!adm&&tab=='search')bindSearch();
}

// ---------- Customer ----------
const subs=m=>{
  const s=m.sub.map(id=>meds.find(x=>x.id==id)).filter(Boolean);
  if(!s.length)return'';
  return`<div class="subs"><b>Substitutes</b>${s.map(x=>`<span class="chip ${status(x)[1]}">${esc(x.name)}, ${rs(x.price)}, ${x.stock>0?x.stock+' left':'none left'}</span>`).join('')}</div>`;
};
const buyBox=(m,c)=>c=='bad'?'<p class="na">Unavailable. Choose a substitute above.</p>':`<div class="buy"><input type="number" id="n${m.id}" value="1" min="1" max="${m.stock}"><button class="btn sm" onclick="purchase(${m.id})">Buy</button></div>`;
const card=(m,why)=>{
  const[st,c]=status(m);
  return`<article class="card"><div class="cardhead"><h3>${esc(m.name)}</h3><span class="badge ${c}">${st}</span></div>
  <p class="cat">${esc(m.cat)}</p>
  <dl><dt>Manufacturer</dt><dd>${esc(m.mfr)}</dd><dt>Cost</dt><dd>${rs(m.price)}</dd><dt>In stock</dt><dd>${m.stock}</dd><dt>Expires</dt><dd>${m.exp}</dd></dl>
  ${subs(m)}${why?`<small class="why">Matched by ${why}</small>`:''}${buyBox(m,c)}</article>`;
};
function renderRes(r){
  if(!r||!r.r)return'';
  if(r.r.length)return`<h3 class="sub">${r.r.length} result${r.r.length>1?'s':''} <small>${r.steps} character comparisons</small></h3><div class="cards">${r.r.map(x=>card(x.m,x.why)).join('')}</div>`;
  if(r.fuzzy.length)return`<h3 class="sub">No exact match. Did you mean:</h3><div class="dym">${r.fuzzy.map(x=>`<button class="chip ok" onclick="$('#q').value='${esc(x.m.name)}';$('#go').click()">${esc(x.m.name)} <small>edit distance ${x.d}</small></button>`).join('')}</div>`;
  return'<h3 class="sub">Nothing found. Check the spelling or try a manufacturer name.</h3>';
}
function cust(){
  if(tab=='txn')return txnTable(txns.filter(t=>t.u==me.u));
  const feat=reservoir(meds.filter(m=>status(m)[1]!='bad'),3);
  return`<section class="searchbox"><h2>What do you need today, ${esc(me.name.split(' ')[0])}?</h2>
  <div class="cap-input"><input id="q" value="${esc(filters.q)}" placeholder="Try dolo, or a typo like azithrl" autocomplete="off"><button class="btn" id="go">Search</button></div>
  <ul id="sug"></ul>
  <div class="filters"><select id="catFilter"><option value="all">All categories</option>${cats().map(c=>`<option value="${esc(c)}" ${filters.cat===c?'selected':''}>${esc(c)}</option>`).join('')}</select><select id="sortFilter"><option value="relevance">Sort: Relevance</option><option value="priceAsc" ${filters.sort==='priceAsc'?'selected':''}>Price: Low to high</option><option value="priceDesc" ${filters.sort==='priceDesc'?'selected':''}>Price: High to low</option><option value="stock" ${filters.sort==='stock'?'selected':''}>Stock: High to low</option><option value="expiry" ${filters.sort==='expiry'?'selected':''}>Expiry: Soonest</option></select><button class="ghost" onclick="filters={q:'',cat:'all',sort:'relevance'};res=null;dash()">Reset</button></div></section>
  <div id="results">${res?renderRes(res):`<h3 class="sub">Featured today</h3><div class="cards">${feat.map(m=>card(m)).join('')}</div>`}</div>`;
}
function bindSearch(){
  const q=$('#q');
  const run=()=>{filters.q=q.value.trim();if(filters.q){res=search(filters.q);if(res&&res.r)res.r=filtered(res.r.map(x=>x.m)).map(m=>({m,why:'Filter/sort'}));}else{res={r:filtered(meds).map(m=>({m,why:'Browse'})),steps:0};}$('#sug').innerHTML='';$('#results').innerHTML=renderRes(res)};
  $('#go').onclick=run;
  q.onkeydown=e=>{if(e.key=='Enter')run()};
  q.oninput=()=>{$('#sug').innerHTML=suggest(q.value).map(n=>`<li onclick="$('#q').value='${esc(n)}';$('#go').click()">${esc(n)}</li>`).join('')};
  $('#catFilter').onchange=e=>{filters.cat=e.target.value;run()};
  $('#sortFilter').onchange=e=>{filters.sort=e.target.value;run()};
}
function purchase(id){
  const m=meds.find(x=>x.id==id),n=+$('#n'+id).value;
  if(!(n>=1)||n>m.stock)return toast('Only '+m.stock+' available');
  m.stock-=n;
  txns.unshift({no:randomPrimeReceipt(),u:me.u,name:me.name,med:m.name,qty:n,total:n*m.price,date:new Date().toLocaleString()});
  save();toast('Bought. Receipt '+txns[0].no);dash();
}

// ---------- Shared and admin ----------
const txnTable=l=>{
  const a=me.role=='admin';
  return`<h2 class="pt">${a?'All customer transactions':'Your transactions'}</h2>`+(l.length?`<div class="tw"><table><tr><th>Receipt</th>${a?'<th>Customer</th>':''}<th>Medicine</th><th>Qty</th><th>Total</th><th>Date</th></tr>
  ${l.map(t=>`<tr><td>${t.no}</td>${a?`<td>${esc(t.name)} (${esc(t.u)})</td>`:''}<td>${esc(t.med)}</td><td>${t.qty}</td><td>${rs(t.total)}</td><td>${t.date}</td></tr>`).join('')}</table></div>`:'<p class="empty">No transactions yet. Buy a medicine and it will appear here.</p>');
};
function admin(){
  if(tab=='txn')return txnTable(txns);
  if(tab=='add')return`<h2 class="pt">Add a medicine</h2><form class="addf" onsubmit="return addMed(event)">
  ${[['name','Name'],['cat','Category'],['mfr','Manufacturer'],['price','Price (₹)','number'],['stock','Stock','number'],['exp','Expiry date','date']].map(f=>`<label>${f[1]}<input name="${f[0]}" type="${f[2]||'text'}" required></label>`).join('')}
  <label class="full">Substitute names, comma separated<input name="sub" placeholder="Dolo 650, Calpol 500"></label><button class="btn">Add medicine</button></form>`;
  const n=f=>meds.filter(f).length,rev=txns.reduce((s,t)=>s+t.total,0);
  const stats=[['Medicines',meds.length],['Out of stock',n(m=>m.stock==0)],['Low stock',n(m=>m.stock>0&&m.stock<=10)],['Expired',n(m=>days(m)<0)],['Expiring in 60 days',n(m=>days(m)>=0&&days(m)<=60)],['Revenue',rs(rev)]];
  return`<div class="stats">${stats.map(s=>`<div class="stat"><b>${s[1]}</b><span>${s[0]}</span></div>`).join('')}</div>
  <h2 class="pt">Inventory</h2><div class="tw"><table><tr><th>ID</th><th>Medicine</th><th>Manufacturer</th><th>Price</th><th>Stock</th><th>Expiry</th><th>Status</th><th></th></tr>
  ${meds.map(m=>{const[s,c]=status(m);return`<tr><td>${m.id}</td><td>${esc(m.name)}</td><td>${esc(m.mfr)}</td><td>${rs(m.price)}</td><td>${m.stock}</td><td>${m.exp}</td><td><span class="badge ${c}">${s}</span></td><td><button class="del" onclick="delMed(${m.id})">Delete</button></td></tr>`}).join('')}</table></div>`;
}
function addMed(e){
  e.preventDefault();
  const f=Object.fromEntries(new FormData(e.target));
  const sub=f.sub.split(',').map(s=>s.trim().toLowerCase()).filter(Boolean).map(s=>(meds.find(m=>m.name.toLowerCase()==s)||{}).id).filter(Boolean);
  const id=Math.max(0,...meds.map(m=>m.id))+1;
  meds.push({id,name:f.name.trim(),cat:f.cat.trim(),mfr:f.mfr.trim(),price:+f.price,stock:+f.stock,exp:f.exp,sub});
  sub.forEach(s=>{const o=meds.find(m=>m.id==s);if(!o.sub.includes(id))o.sub.push(id)});
  save();buildIndex();toast('Medicine added');tab='stock';dash();return false;
}
function delMed(id){
  if(!confirm('Delete this medicine?'))return;
  meds=meds.filter(m=>m.id!=id);meds.forEach(m=>m.sub=m.sub.filter(s=>s!=id));
  save();buildIndex();res=null;toast('Medicine deleted');dash();
}

buildIndex();home();
