// Seed data: loaded once, then kept in the browser's file storage (localStorage). sub = ids of substitute medicines.
const SEED=[
{id:1,name:"Crocin 500",cat:"Fever & Pain",mfr:"GSK",price:30,stock:120,exp:"2027-06-30",sub:[2,3]},
{id:2,name:"Dolo 650",cat:"Fever & Pain",mfr:"Micro Labs",price:32,stock:0,exp:"2027-03-31",sub:[1,3]},
{id:3,name:"Calpol 500",cat:"Fever & Pain",mfr:"GSK",price:28,stock:60,exp:"2026-11-20",sub:[1,2]},
{id:4,name:"Azithral 500",cat:"Antibiotic",mfr:"Alembic",price:118,stock:45,exp:"2027-09-30",sub:[5]},
{id:5,name:"Azee 500",cat:"Antibiotic",mfr:"Cipla",price:122,stock:8,exp:"2027-01-31",sub:[4]},
{id:6,name:"Pantop 40",cat:"Antacid",mfr:"Aristo",price:145,stock:70,exp:"2027-12-31",sub:[7,8]},
{id:7,name:"Pan D",cat:"Antacid",mfr:"Alkem",price:160,stock:3,exp:"2026-12-15",sub:[6,8]},
{id:8,name:"Omez 20",cat:"Antacid",mfr:"Dr Reddys",price:52,stock:90,exp:"2028-02-29",sub:[6,7]},
{id:9,name:"Cetzine 10",cat:"Antiallergic",mfr:"GSK",price:45,stock:100,exp:"2027-08-31",sub:[10]},
{id:10,name:"Okacet",cat:"Antiallergic",mfr:"Cipla",price:22,stock:15,exp:"2026-08-30",sub:[9]},
{id:11,name:"Glycomet 500",cat:"Antidiabetic",mfr:"USV",price:36,stock:85,exp:"2027-05-31",sub:[12]},
{id:12,name:"Riomet 500",cat:"Antidiabetic",mfr:"Sun Pharma",price:34,stock:50,exp:"2027-10-31",sub:[11]},
{id:13,name:"Augmentin 625",cat:"Antibiotic",mfr:"GSK",price:201,stock:25,exp:"2027-04-30",sub:[4]},
{id:14,name:"Volini Gel",cat:"Pain Relief",mfr:"Sun Pharma",price:135,stock:40,exp:"2027-07-31",sub:[]}];
const ALGOS=[
["KMP (Module 2)","Finds the typed text inside medicine names in linear time."],
["Rabin-Karp (Module 2)","A rolling hash matches manufacturers and categories."],
["Suffix array (Module 2)","Gives instant autocomplete suggestions as you type."],
["Edit distance (Module 3)","Wagner-Fischer DP fixes spelling mistakes."],
["Miller-Rabin (Module 6)","Every receipt number is a verified prime."],
["Reservoir sampling (Module 6)","Picks fair random featured medicines."]];
